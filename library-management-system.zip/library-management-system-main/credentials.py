# User Credentials
host = 'localhost'
user = 'Your username here'
password = 'Your password here'
database = 'library_management'
